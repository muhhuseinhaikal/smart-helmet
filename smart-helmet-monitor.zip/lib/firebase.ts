import { initializeApp } from "firebase/app"
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore"
import { getAuth } from "firebase/auth"
import { firebaseConfig } from "@/config/firebase_config"

// Initialize Firebase app
const app = initializeApp(firebaseConfig)

// Initialize Firestore
export const db = getFirestore(app)

// Initialize Auth
export const auth = getAuth(app)

// Connect to emulator in development (optional)
if (typeof window !== "undefined" && process.env.NODE_ENV === "development") {
  if (process.env.NEXT_PUBLIC_USE_EMULATOR === "true") {
    try {
      connectFirestoreEmulator(db, "localhost", 8080)
    } catch (error) {
      console.log("Emulator already connected")
    }
  }
}

export default app
